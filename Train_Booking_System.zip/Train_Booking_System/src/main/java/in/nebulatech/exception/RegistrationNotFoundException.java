package in.nebulatech.exception;


public class RegistrationNotFoundException extends Exception {
	
	public RegistrationNotFoundException(String s) {
		super(s);
	}

}
