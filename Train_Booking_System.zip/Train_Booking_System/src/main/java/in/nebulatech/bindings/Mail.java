package in.nebulatech.bindings;

import lombok.Data;

@Data
public class Mail {
	
	private String mailId;
	
	private String mailSub;
	
	private String mailBody;
	

}
