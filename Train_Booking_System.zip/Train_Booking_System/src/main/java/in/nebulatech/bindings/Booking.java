package in.nebulatech.bindings;



import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@Entity
@Table(name="BOOKING_RECORDS")
public class Booking {
	
	

	@Id
	private String name;
	
	private String email;
	
	private Long contact;
	
	private String fromLocation;
	
	private Integer count;
	
	private String toLocation;
	
	private String checkInDate;
	
	private String trainPreferences;
	
	private String passengerCatagory;
	

}
