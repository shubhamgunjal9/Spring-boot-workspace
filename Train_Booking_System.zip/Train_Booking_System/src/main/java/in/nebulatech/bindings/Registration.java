package in.nebulatech.bindings;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="REGISTRATION_DATA")
public class Registration {
	
	
	@Id
	private String username;
	
	private String password;

	private String dateofbirth;

	private String maritalStatus;
 
	private String address;

	private String contact;

	private String email;
	
	private String gender;
	
	//private String resetPasswordToken;


}
